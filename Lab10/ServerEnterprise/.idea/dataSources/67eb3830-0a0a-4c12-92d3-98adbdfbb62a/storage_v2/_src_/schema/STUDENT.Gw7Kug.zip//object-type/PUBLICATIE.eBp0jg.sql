create TYPE publicatie AS OBJECT
        (titlu varchar2(20),
        autor varchar2(10),
        editura varchar2(10),
        data_publicare date, 
        localitate varchar2(10),
        rating double precision,
        pret number(3), 
        CONSTRUCTOR FUNCTION publicatie(titlu varchar2, autor varchar2)
        RETURN SELF AS RESULT,
        member procedure vechime,
        NOT FINAL member procedure calitate,
        order member function compara(obj publicatie) RETURN NUMBER
    )NOT FINAL;
/

