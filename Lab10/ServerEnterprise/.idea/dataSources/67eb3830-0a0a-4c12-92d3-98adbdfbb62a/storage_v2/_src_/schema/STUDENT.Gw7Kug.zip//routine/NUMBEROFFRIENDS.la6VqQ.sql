create FUNCTION numberOfFriends(p_nr_matricol varchar2)
    RETURN integer
AS
    v_rezultat integer := 0;
    v_id integer;
BEGIN
    SELECT id INTO v_id FROM STUDENTI WHERE nr_matricol = p_nr_matricol;
    SELECT count(*) INTO v_rezultat FROM PRIETENI WHERE id_student1 = v_id;
    return v_rezultat;
END;
/

