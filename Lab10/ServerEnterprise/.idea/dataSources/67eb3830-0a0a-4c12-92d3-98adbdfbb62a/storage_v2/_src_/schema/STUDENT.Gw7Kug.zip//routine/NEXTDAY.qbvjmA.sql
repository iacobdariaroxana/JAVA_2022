create PROCEDURE nextDay (p_date IN OUT DATE default SYSDATE) AS
BEGIN
   p_date := p_date + 1;
END;
/

