create PROCEDURE write_students AS
    CURSOR lista_studenti IS SELECT s.nume, s.prenume,s.grupa, s.an, AVG(n.valoare) AS medie 
        FROM studenti s JOIN note n ON s.id = n.id_student
        GROUP BY s.id,s.nume,s.prenume,s.an,s.grupa
        ORDER BY grupa, medie DESC, nume,prenume;

    v_file_an1 UTL_FILE.FILE_TYPE;
    v_file_an2 UTL_FILE.FILE_TYPE;
    v_file_an3 UTL_FILE.FILE_TYPE;

    v_grupa_an1 studenti.grupa%TYPE := 'A';
    v_grupa_an2 studenti.grupa%TYPE := 'A';
    v_grupa_an3 studenti.grupa%TYPE := 'A';

BEGIN
    v_file_an1 := UTL_FILE.FOPEN('mydir', 'anul_1.txt', 'w');
    v_file_an2 := UTL_FILE.FOPEN('mydir', 'anul_2.txt', 'w');
    v_file_an3 := UTL_FILE.FOPEN('mydir', 'anul_3.txt', 'w');

    FOR stud IN lista_studenti LOOP
        IF (stud.an = 1) THEN
            IF (v_grupa_an1 != stud.grupa) THEN 
                UTL_FILE.PUT_LINE(v_file_an1, '== GRUPA' || stud.grupa || '==');
                v_grupa_an1 := stud.grupa;
            END IF;
            UTL_FILE.PUT_LINE(v_file_an1, stud.nume ||' '|| stud.prenume ||' '|| stud.medie);
        ELSIF (stud.an = 2) THEN
            IF (v_grupa_an2 != stud.grupa) THEN 
                UTL_FILE.PUT_LINE(v_file_an2, '== GRUPA' || stud.grupa || '==');
                v_grupa_an2 := stud.grupa;
            END IF;
            IF (v_grupa_an3 != stud.grupa) THEN 
                UTL_FILE.PUT_LINE(v_file_an3, '== GRUPA' || stud.grupa || '==');
                v_grupa_an3 := stud.grupa;
            END IF;
            UTL_FILE.PUT_LINE(v_file_an2, stud.nume ||' '|| stud.prenume ||' '|| stud.medie);
        ELSIF (stud.an = 3) THEN
            UTL_FILE.PUT_LINE(v_file_an3, stud.nume ||' '|| stud.prenume ||' '|| stud.medie);
        END IF;
    END LOOP;
    UTL_FILE.FCLOSE(v_file_an1);
    UTL_FILE.FCLOSE(v_file_an2);
    UTL_FILE.FCLOSE(v_file_an3);
END;
/

