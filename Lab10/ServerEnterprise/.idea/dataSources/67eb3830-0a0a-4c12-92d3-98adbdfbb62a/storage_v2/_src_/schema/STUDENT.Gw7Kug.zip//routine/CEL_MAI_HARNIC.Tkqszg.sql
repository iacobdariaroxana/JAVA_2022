create procedure cel_mai_harnic as
    v_max int;
    lista lista_profesori;
begin
    select max(count(*)) into v_max from didactic d join profesori p on d.id_profesor=p.id group by p.id;
--    DBMS_OUTPUT.PUT_LINE(v_max);
    SELECT distinct p.nume||' '||p.prenume BULK COLLECT INTO lista FROM
            profesori p join didactic d on p.id=d.id_profesor where 
            (select count(*) from didactic dd join profesori pp on dd.id_profesor=pp.id group by pp.id having pp.id=p.id)=v_max;
    for i in lista.first..lista.last loop
       DBMS_OUTPUT.PUT_LINE(i||' - '||lista(i));    
    end loop;
end;
/

