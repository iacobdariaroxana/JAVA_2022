create procedure afiseaza as
    my_name varchar2(20):='Gigel';
begin
    dbms_output.put_line('Ma cheama '|| my_name);
end afiseaza;
/

