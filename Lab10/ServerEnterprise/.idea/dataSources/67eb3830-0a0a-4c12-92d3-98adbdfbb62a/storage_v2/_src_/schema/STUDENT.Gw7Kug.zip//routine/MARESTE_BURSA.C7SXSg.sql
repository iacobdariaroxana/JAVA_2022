create FUNCTION mareste_bursa
        (pi_id_student IN studenti.id%type)
    RETURN VARCHAR2
AS
    bursa_student studenti.bursa%type;
    mesaj VARCHAR2(32767);
    counter INTEGER;
BEGIN
    SELECT COUNT(*) INTO counter FROM studenti WHERE id = pi_id_student ;
    IF counter = 0 THEN
        raise my_exceptions.student_inexistent;
    ELSE
        SELECT bursa INTO bursa_student FROM studenti WHERE id = pi_id_student ;
        IF bursa_student is null THEN
            raise my_exceptions.student_fara_bursa;
        END IF;
    END IF;
    bursa_student := bursa_student + 10;
    update studenti set bursa = bursa_student where id = pi_id_student;
    mesaj := 'Am marit cu 10 lei bursa studentului cu ID-ul ' || pi_id_student || '.';
    RETURN mesaj;
END mareste_bursa;
/

