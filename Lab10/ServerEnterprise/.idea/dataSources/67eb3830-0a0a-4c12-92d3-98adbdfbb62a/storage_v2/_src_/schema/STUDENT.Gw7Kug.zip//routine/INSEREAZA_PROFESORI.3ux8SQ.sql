create PROCEDURE insereaza_profesori AS
    lista lista_profesori;
BEGIN
    for v_cursuri in (select id from cursuri) loop
        lista := lista_profesori();
        SELECT p.nume||' '||p.prenume BULK COLLECT INTO lista FROM
            profesori p join didactic d on p.id=d.id_profesor where id_curs=v_cursuri.id;

        UPDATE cursuri SET lista_profesori = lista WHERE cursuri.id = v_cursuri.id;  
    end loop;
END;
/

