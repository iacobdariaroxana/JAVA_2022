create PACKAGE BODY facultate IS
    PROCEDURE adauga_curs(p_id cursuri.id%type, 
                          p_titlu_curs cursuri.titlu_curs%type, 
                          p_an cursuri.an%type, 
                          p_semestru cursuri.semestru%type, 
                          p_credite cursuri.credite%type)
    AS
    BEGIN
        INSERT INTO cursuri(id, titlu_curs, an, semestru, credite, created_at, updated_at) 
            values (p_id, p_titlu_curs, p_an, p_semestru, p_credite, SYSDATE, SYSDATE);
    END adauga_curs;

    PROCEDURE sterge_curs(p_id cursuri.id%type,
                          p_count_sterse in out int)
    AS
    BEGIN
        delete from note where id_curs = p_id;
        IF(SQL%FOUND)THEN
            p_count_sterse := SQL%ROWCOUNT;
        ELSE
            p_count_sterse := 0;
        END IF;
        --delete from cursuri where id = p_id;
    END sterge_curs;

    PROCEDURE sterge_curs(p_titlu_curs cursuri.titlu_curs%type, 
                          p_count_sterse in out int) 
    AS
    BEGIN
        delete from note where id_curs = (select id from cursuri where titlu_curs = p_titlu_curs);
        IF(SQL%FOUND) THEN
            p_count_sterse := SQL%ROWCOUNT;
        ELSE
            p_count_sterse := 0;
        END IF;
        --delete from cursuri where cursuri.titlu_curs = p_titlu_curs ;
    END sterge_curs;

    FUNCTION medie_curs(p_id cursuri.id%type) 
        return double precision
    AS
        v_medie double precision;
    BEGIN
        select avg(valoare) into v_medie from note where id_curs = p_id;
        return v_medie;
    END medie_curs;
END facultate;
/

