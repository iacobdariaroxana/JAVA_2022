create PROCEDURE inc (p_val IN OUT NUMBER) AS
BEGIN
   p_val := p_val + 1;
END;
/

