create TYPE revista UNDER publicatie
(    
   an NUMBER(5),
   numar NUMBER(3),
   OVERRIDING member procedure calitate
)
/

