create PROCEDURE squareNumber(x IN OUT number) IS 
BEGIN 
  x := x * x; 
END;
/

