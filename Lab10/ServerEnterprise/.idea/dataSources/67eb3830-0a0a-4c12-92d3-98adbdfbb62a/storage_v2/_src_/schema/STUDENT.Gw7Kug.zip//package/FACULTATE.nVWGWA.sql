create PACKAGE facultate AS
    PROCEDURE adauga_curs(p_id cursuri.id%type, 
                          p_titlu_curs cursuri.titlu_curs%type, 
                          p_an cursuri.an%type, 
                          p_semestru cursuri.semestru%type, 
                          p_credite cursuri.credite%type);

    PROCEDURE sterge_curs(p_id cursuri.id%type, 
                          p_count_sterse in out int);

    PROCEDURE sterge_curs(p_titlu_curs cursuri.titlu_curs%type, 
                          p_count_sterse in out int);

    FUNCTION medie_curs(p_id cursuri.id%type) 
        return double precision;
END facultate;
/

