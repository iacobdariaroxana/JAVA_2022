create TYPE BODY publicatie AS
    CONSTRUCTOR FUNCTION publicatie(titlu varchar2, autor varchar2)
        RETURN SELF AS RESULT
    AS
        BEGIN
            SELF.titlu := titlu;
            SELF.autor := autor;
            SELF.editura := 'unknown';
            SELF.data_publicare := sysdate;
            SELF.localitate := 'Iasi';
            SELF.rating := 1.00;
            SELF.pret := 0;
            RETURN;
        END;
    MEMBER PROCEDURE vechime IS
        BEGIN
            DBMS_OUTPUT.PUT_LINE('Publicatia ' || self.titlu || ' de ' 
            || self.autor || ' are vechimea de ' || MONTHS_BETWEEN(sysdate, data_publicare) || ' luni.');
        END vechime;
    MEMBER PROCEDURE calitate IS
        BEGIN
            if (rating < 2)  then
                DBMS_OUTPUT.PUT_LINE('Publicatia este slab recomandata.');
            else if (rating < 4 ) then
                    DBMS_OUTPUT.PUT_LINE('Publicatia este in general recomandata.');
                else
                    DBMS_OUTPUT.PUT_LINE('Publicatia este foarte recomandata.');
                end if;
            end if;
        END calitate;
    ORDER MEMBER FUNCTION compara(obj publicatie) RETURN NUMBER IS
        BEGIN
            if (SELF.rating < obj.rating)  then
                return -1;
            else if (SELF.rating > obj.rating) then
                    return 1;
                else
                    return 0;
                end if;
            end if;
        END compara;        
END;
/

