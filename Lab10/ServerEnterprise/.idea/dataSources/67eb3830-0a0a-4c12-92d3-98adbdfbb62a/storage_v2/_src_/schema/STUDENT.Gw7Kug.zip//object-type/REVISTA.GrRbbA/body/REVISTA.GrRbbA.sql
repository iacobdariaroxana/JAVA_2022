create TYPE BODY revista AS
    OVERRIDING MEMBER PROCEDURE calitate IS
        BEGIN
            if (an < 2020)  then
                DBMS_OUTPUT.PUT_LINE('Revista este veche.');
            else if (rating < 2021 ) then
                    DBMS_OUTPUT.PUT_LINE('Revista este recenta.');
                else
                    DBMS_OUTPUT.PUT_LINE('Revista este noua.');
                end if;
            end if;
        END calitate;
END;
/

