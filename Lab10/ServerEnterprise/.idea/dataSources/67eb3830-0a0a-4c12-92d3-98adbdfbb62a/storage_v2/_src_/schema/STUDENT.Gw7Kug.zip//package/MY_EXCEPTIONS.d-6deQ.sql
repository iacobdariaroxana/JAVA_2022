create PACKAGE my_exceptions AS
    student_inexistent EXCEPTION;
    PRAGMA EXCEPTION_INIT(student_inexistent, -20001);
    student_fara_bursa EXCEPTION;
    PRAGMA EXCEPTION_INIT(student_fara_bursa, -20002);
END my_exceptions;
/

