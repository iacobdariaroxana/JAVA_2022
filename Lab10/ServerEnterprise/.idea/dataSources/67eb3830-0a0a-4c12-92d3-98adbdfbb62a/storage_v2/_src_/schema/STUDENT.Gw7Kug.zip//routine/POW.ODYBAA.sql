create PROCEDURE pow(p_baza IN INTEGER := 3, 
                                  p_exponent IN INTEGER DEFAULT 5, 
                                  p_out OUT INTEGER) AS   
BEGIN
    IF p_exponent < 0 THEN
        DBMS_OUTPUT.PUT_LINE('Exponent is negative - not supported!');
        RETURN;
    END IF;
    p_out := p_baza ** p_exponent;    
END;
/

