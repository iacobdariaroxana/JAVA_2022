create FUNCTION nota_recenta_student(
    pi_id_student IN studenti.id%type)
  RETURN VARCHAR2
AS
  nota_recenta       INTEGER;
  mesaj              VARCHAR2(32767);
  counter            INTEGER;
  student_inexistent EXCEPTION;
  PRAGMA EXCEPTION_INIT(student_inexistent, -20001);
  student_fara_note EXCEPTION;
  PRAGMA EXCEPTION_INIT(student_fara_note, -20002);
BEGIN
  SELECT COUNT(*) INTO counter FROM studenti WHERE id = pi_id_student ;
  IF counter = 0 THEN
    raise student_inexistent;
  ELSE
    SELECT COUNT(*) INTO counter FROM note WHERE id_student = pi_id_student ;
    IF counter = 0 THEN
      raise student_fara_note;
    END IF;
  END IF;
SELECT valoare
INTO nota_recenta
FROM
  (SELECT valoare
  FROM note
  WHERE id_student = pi_id_student 
  ORDER BY data_notare DESC
  )
WHERE rownum <= 1;
mesaj        := 'Cea mai recenta nota a studentului cu ID-ul ' || pi_id_student || ' este ' || nota_recenta || '.';
RETURN mesaj;
EXCEPTION
WHEN student_inexistent THEN
  raise_application_error (-20001,'Studentul cu ID-ul ' || pi_id_student || ' nu exista in baza de date.');
WHEN student_fara_note THEN
  raise_application_error (-20002,'Studentul cu ID-ul ' || pi_id_student || ' nu are nici o nota.');
END nota_recenta_student;
/

